package com.abdul.springprojects;

import org.apache.camel.CamelContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class RouteOrder {
	
	@Autowired
	private CamelContext context;
	
	
	
	
	

}
