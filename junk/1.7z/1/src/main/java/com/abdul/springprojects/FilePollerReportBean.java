package com.abdul.springprojects;

public class FilePollerReportBean {
	
	
	public void createReport(String numOfNewFiles, String fileStore) {
		
		
	}

}
