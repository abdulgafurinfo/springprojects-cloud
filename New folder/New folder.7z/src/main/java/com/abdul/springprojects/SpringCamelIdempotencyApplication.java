package com.abdul.springprojects;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCamelIdempotencyApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCamelIdempotencyApplication.class, args);
	}
}
